﻿using System.Windows;

namespace AdminApp
{
    public partial class App : Application
    {
    }
}
